CREATE DATABASE IF NOT EXISTS thuchanh_php_f_bai08_15 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE thuchanh_php_f_bai08_15;

CREATE TABLE IF NOT EXISTS nguoidung (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tintuc (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    img_url VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS rating_info (
    product_id INT UNSIGNED PRIMARY KEY,
    rate_1 INT UNSIGNED NOT NULL DEFAULT 0,
    rate_2 INT UNSIGNED NOT NULL DEFAULT 0,
    rate_3 INT UNSIGNED NOT NULL DEFAULT 0,
    rate_4 INT UNSIGNED NOT NULL DEFAULT 0,
    rate_5 INT UNSIGNED NOT NULL DEFAULT 0,
    FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS news (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    link VARCHAR(1000) NOT NULL,
    description VARCHAR(1000) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS binhchon (
    idBC INT UNSIGNED PRIMARY KEY,
    MoTa VARCHAR(255) NOT NULL,
    SoLanChon INT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS phuongan (
    idPA INT UNSIGNED PRIMARY KEY,
    idBC INT UNSIGNED NOT NULL,
    MoTa VARCHAR(255) NOT NULL,
    SoLanChon INT UNSIGNED NOT NULL DEFAULT 0,
    FOREIGN KEY (idBC) REFERENCES binhchon(idBC)
) ENGINE=InnoDB;

START TRANSACTION;
INSERT IGNORE INTO nguoidung (username, password_hash)
VALUES ('thuchanh', '$2y$10$oFbURYc/rpFxjSo0vNdeSugaC97W5UtUuUo.ChLn1Dahh422a7GIK');

INSERT IGNORE INTO tintuc (id, title)
SELECT n, CONCAT('Tin mẫu số ', n)
FROM (
    SELECT 1 + a.n + 10 * b.n + 100 * c.n AS n
    FROM (SELECT 0 n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
          UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a
    CROSS JOIN (SELECT 0 n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
          UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) b
    CROSS JOIN (SELECT 0 n UNION ALL SELECT 1) c
) numbers ORDER BY n;

INSERT IGNORE INTO products VALUES
    (1, 'MB Gigabyte G1.Sniper B5', 'images/1.svg'),
    (2, 'Asus MeMo Pad ME102A', 'images/2.svg'),
    (3, 'LCD Philips 27″ 273G3 DHSW', 'images/3.svg');

INSERT IGNORE INTO rating_info VALUES
    (1, 1, 2, 3, 1, 2),
    (2, 12, 23, 21, 22, 11),
    (3, 2, 2, 1, 1, 2);

INSERT IGNORE INTO news VALUES
    (1, 'Soạn thảo nội dung với CKEditor', 'bai08/', 'Tạo trình soạn thảo và gửi nội dung về PHP.'),
    (2, 'Tải ảnh lên máy chủ', 'bai09/', 'Kiểm tra định dạng JPG & GIF trước khi lưu ảnh.'),
    (3, 'Lưu trạng thái với Session', 'bai10/', 'Tạo bộ đếm và bảo vệ trang quản trị.'),
    (4, 'Phân trang tin tức', 'bai11/', 'Lấy từng nhóm tin bằng LIMIT và OFFSET.');

INSERT IGNORE INTO binhchon VALUES (1, 'Bạn đánh giá thế nào về chất lượng trang web ute.udn.vn?', 0);
INSERT IGNORE INTO phuongan VALUES
    (1, 1, 'Rất tốt', 0), (2, 1, 'Tốt', 0), (3, 1, 'Bình thường', 0), (4, 1, 'Cần cải thiện', 0);
COMMIT;

