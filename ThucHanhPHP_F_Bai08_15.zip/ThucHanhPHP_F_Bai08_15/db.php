<?php
require_once __DIR__ . '/common.php';

function db(): PDO
{
    static $pdo;
    if ($pdo === null) {
        $port = getenv('PHPF_DB_PORT') ?: '3306';
        $user = getenv('PHPF_DB_USER') ?: 'root';
        $password = getenv('PHPF_DB_PASSWORD');
        try {
            $pdo = new PDO(
                "mysql:host=127.0.0.1;port=$port;dbname=thuchanh_php_f_bai08_15;charset=utf8mb4",
                $user,
                $password === false ? '' : $password,
                [PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
            );
        } catch (PDOException $exception) {
            http_response_code(503);
            header('Content-Type: text/plain; charset=UTF-8');
            exit('Chưa kết nối được MySQL. Hãy bật MySQL và nhập database.sql theo README.');
        }
    }
    return $pdo;
}

