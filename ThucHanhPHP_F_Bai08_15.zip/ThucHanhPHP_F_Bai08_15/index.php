<?php
require __DIR__ . '/common.php';
$titles = [
    8 => 'Soạn thảo với CKEditor', 'Tải ảnh lên máy chủ',
    'Biến Session, bộ đếm và đăng nhập', 'Phân trang tin tức', 'Đánh giá sản phẩm',
    'Tạo nguồn tin RSS', 'Xác minh CAPTCHA', 'Bình chọn và tính tỷ lệ',
];
?>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Thực hành PHP từ Bài 8 đến Bài 15</title>
    <link rel="stylesheet" href="style.css">
</head>
<body><main>
    <h1>Thực hành PHP từ Bài 8 đến Bài 15</h1>
    <p>Chọn một bài để thử biểu mẫu và xem kết quả. Các bài dùng MySQL có dữ liệu mẫu trong <code>database.sql</code>.</p>
    <div class="grid">
        <?php foreach ($titles as $number => $title): ?>
            <a class="card" href="bai<?= sprintf('%02d', $number) ?>/">
                <strong>Bài <?= sprintf('%02d', $number) ?></strong><?= e($title) ?>
            </a>
        <?php endforeach ?>
    </div>
</main></body></html>

